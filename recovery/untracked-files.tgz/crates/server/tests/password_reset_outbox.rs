//! Password-reset delivery through the durable outbox (closes the
//! "password-reset integration test" gap).
//!
//! Two layers:
//!
//! 1. **Hermetic (always runs)** — the request endpoint answers the same
//!    shape without a database, so a missing database never reveals whether
//!    an account exists.
//! 2. **Durable (`POSTGRES_URL` required, else NOT_RUN)** — a real account is
//!    registered, a reset is requested, and the reset email must appear as a
//!    `password_reset` row in `email_outbox` (no mail server needed). An
//!    unknown address must produce the identical response and NO outbox row.
//!    A second request must revoke the first, unused token.

use std::sync::Arc;

use axum::body::Body;
use axum::http::{Request, StatusCode};
use serde_json::{json, Value};
use tower::ServiceExt;

use bot_core::audit::AuditTrail;
use bot_core::auth::RateLimiter;
use bot_core::config::{AppConfig, DatabaseConfig};
use bot_core::db::Database;
use bot_core::obs::health::HealthRegistry;
use bot_core::state::AppState;

use sniper_suite::api::{router, ApiState};
use sniper_suite::saas::SaasStore;

const PASSWORD: &str = "correct-horse-battery";

fn pg_url() -> Option<String> {
    std::env::var("POSTGRES_URL")
        .ok()
        .filter(|s| !s.trim().is_empty())
}

async fn setup_db() -> Option<Arc<Database>> {
    let url = pg_url()?;
    let cfg = DatabaseConfig {
        enabled: true,
        auto_migrate: true,
        ..Default::default()
    };
    let db = Database::connect(&cfg, &url).await.expect("connect");
    db.migrate().await.expect("migrate");
    Some(Arc::new(db))
}

/// Per-run suffix so emails never collide with rows left in a persistent
/// test database.
fn run_id() -> &'static str {
    static ID: std::sync::OnceLock<String> = std::sync::OnceLock::new();
    ID.get_or_init(|| uuid::Uuid::new_v4().simple().to_string()[..12].to_string())
}

fn account_email() -> String {
    format!("reset-{}@example.com", run_id())
}

fn unknown_email() -> String {
    format!("nobody-{}@example.com", run_id())
}

fn state_with(saas: Arc<SaasStore>, db: Option<Arc<Database>>) -> ApiState {
    let shared = AppState::new(AppConfig::from_defaults());
    ApiState {
        audit: AuditTrail::new(None, shared.events.clone()),
        shared,
        api_key: None,
        auth: None,
        limiter: RateLimiter::new(0),
        sensitive_limiter: RateLimiter::new(0),
        db,
        journal: None,
        serve_dashboard: false,
        health: Arc::new(HealthRegistry::new()),
        metrics_enabled: false,
        saas,
        trading: None,
        module_registry: Arc::new(
            sniper_suite::module_runtime::module_registry::TenantModuleRegistry::new(),
        ),
    }
}

async fn request(
    state: ApiState,
    method: &str,
    path: &str,
    body: Option<Value>,
) -> (StatusCode, Value) {
    let app = router(state);
    let mut builder = Request::builder().method(method).uri(path);
    if body.is_some() {
        builder = builder.header("content-type", "application/json");
    }
    let request = builder
        .body(Body::from(body.map(|v| v.to_string()).unwrap_or_default()))
        .expect("build request");
    let response = app.oneshot(request).await.expect("oneshot");
    let status = response.status();
    let bytes = axum::body::to_bytes(response.into_body(), 1 << 20)
        .await
        .expect("body");
    let value: Value = if bytes.is_empty() {
        Value::Null
    } else {
        serde_json::from_slice(&bytes)
            .unwrap_or(Value::String(String::from_utf8_lossy(&bytes).into_owned()))
    };
    (status, value)
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn reset_request_without_database_is_generic_and_hermetic() {
    let saas = Arc::new(SaasStore::new());
    let (status, body) = request(
        state_with(saas, None),
        "POST",
        "/api/saas/password-reset/request",
        Some(json!({ "email": account_email() })),
    )
    .await;
    assert!(
        status.is_success(),
        "request without a database must answer the generic accepted shape, got {status}"
    );
    assert!(
        !body.to_string().contains("reset-"),
        "response must not echo the submitted address"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn reset_email_is_queued_in_outbox_and_unknown_address_is_not() {
    let Some(db) = setup_db().await else {
        eprintln!("NOT_RUN: password-reset outbox — POSTGRES_URL missing");
        return;
    };
    let saas = Arc::new(
        SaasStore::with_database(Some(db.clone()))
            .await
            .expect("durable saas store"),
    );
    let email = account_email();

    // 1. Register the account (201, or 409 if a previous run left it behind).
    let (status, _) = request(
        state_with(saas.clone(), Some(db.clone())),
        "POST",
        "/api/saas/users",
        Some(json!({ "email": email, "password": PASSWORD, "display_name": "Reset" })),
    )
    .await;
    assert!(
        status == StatusCode::CREATED || status == StatusCode::CONFLICT,
        "registration of {email}: {status}"
    );

    // 2. Known account: request a reset.
    let (known_status, known_body) = request(
        state_with(saas.clone(), Some(db.clone())),
        "POST",
        "/api/saas/password-reset/request",
        Some(json!({ "email": email })),
    )
    .await;
    assert!(known_status.is_success(), "known request: {known_status}");

    let queued: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM email_outbox
          WHERE lower(recipient) = lower($1) AND template_key = 'password_reset'",
    )
    .bind(&email)
    .fetch_one(db.pool())
    .await
    .expect("count outbox rows");
    assert!(queued >= 1, "reset email must be queued in email_outbox");

    let (status_text,): (String,) = sqlx::query_as(
        "SELECT status FROM email_outbox
          WHERE lower(recipient) = lower($1) AND template_key = 'password_reset'
          ORDER BY created_at DESC LIMIT 1",
    )
    .bind(&email)
    .fetch_one(db.pool())
    .await
    .expect("latest outbox row");
    assert_eq!(status_text, "pending", "a fresh reset email starts pending");

    // 3. Unknown address: identical response, and no outbox row for it.
    let unknown = unknown_email();
    let (unk_status, unk_body) = request(
        state_with(saas.clone(), Some(db.clone())),
        "POST",
        "/api/saas/password-reset/request",
        Some(json!({ "email": unknown })),
    )
    .await;
    assert_eq!(
        unk_status, known_status,
        "status must not reveal the account"
    );
    assert_eq!(unk_body, known_body, "body must not reveal the account");
    let unknown_rows: i64 =
        sqlx::query_scalar("SELECT count(*) FROM email_outbox WHERE lower(recipient) = lower($1)")
            .bind(&unknown)
            .fetch_one(db.pool())
            .await
            .expect("count unknown rows");
    assert_eq!(
        unknown_rows, 0,
        "no email may be queued for an unknown address"
    );

    // 4. A second request revokes the first unused token: exactly one live token.
    let before: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM password_reset_tokens t
           JOIN users u ON u.id = t.user_id
          WHERE lower(u.email) = lower($1) AND t.used_at IS NULL AND t.revoked_at IS NULL",
    )
    .bind(&email)
    .fetch_one(db.pool())
    .await
    .expect("count live tokens");
    let (again, _) = request(
        state_with(saas, Some(db.clone())),
        "POST",
        "/api/saas/password-reset/request",
        Some(json!({ "email": email })),
    )
    .await;
    assert!(again.is_success(), "second request: {again}");
    let after: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM password_reset_tokens t
           JOIN users u ON u.id = t.user_id
          WHERE lower(u.email) = lower($1) AND t.used_at IS NULL AND t.revoked_at IS NULL",
    )
    .bind(&email)
    .fetch_one(db.pool())
    .await
    .expect("count live tokens after");
    assert_eq!(before, 1, "one live token after the first request");
    assert_eq!(
        after, 1,
        "the second request must revoke the first live token"
    );
}
