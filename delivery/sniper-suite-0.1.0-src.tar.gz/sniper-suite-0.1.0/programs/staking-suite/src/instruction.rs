//! Instruction definitions and (de)serialisation.
//!
//! Instructions are borsh-encoded; the first byte is the variant discriminant.
//! Each variant documents the accounts it expects (see `processor` for the
//! authoritative ordering and signer/writable flags).

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::{
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    sysvar,
};
use solana_system_interface::program as system_program;

use crate::error::StakingError;
use crate::state::{config_pda, stake_pda};

/// The program's instruction set.
#[derive(BorshSerialize, BorshDeserialize, Clone, Debug, PartialEq, Eq)]
pub enum StakingInstruction {
    /// Create the mint, vault and treasury token accounts and store the config.
    ///
    /// Accounts:
    /// 0. `[writable, signer]` Payer / admin.
    /// 1. `[writable]` Config PDA.
    /// 2. `[writable, signer]` Mint (new keypair).
    /// 3. `[writable]` Vault (ATA of config PDA).
    /// 4. `[writable]` Treasury token account (ATA of treasury wallet).
    /// 5. `[]` Treasury wallet.
    /// 6. `[]` Token program.
    /// 7. `[]` Associated token program.
    /// 8. `[]` System program.
    /// 9. `[]` Rent sysvar.
    Initialize {
        fee_bps: u16,
        reward_rate_bps: u64,
        min_stake: u64,
        unstake_delay: i64,
        decimals: u8,
        timelock_secs: i64,
    },
    /// Deposit `amount` tokens (fee goes to the treasury).
    ///
    /// Accounts:
    /// 0. `[writable, signer]` Staker.
    /// 1. `[writable]` Staker's source token account.
    /// 2. `[writable]` Vault.
    /// 3. `[writable]` Treasury token account.
    /// 4. `[writable]` Stake PDA.
    /// 5. `[]` Config PDA.
    /// 6. `[]` Token program.
    /// 7. `[]` System program.
    /// 8. `[]` Clock sysvar.
    Stake { amount: u64 },
    /// Withdraw principal + accrued rewards after the cooldown.
    ///
    /// Accounts:
    /// 0. `[writable, signer]` Staker.
    /// 1. `[writable]` Staker's destination token account.
    /// 2. `[writable]` Vault.
    /// 3. `[writable]` Mint.
    /// 4. `[writable]` Stake PDA.
    /// 5. `[]` Config PDA.
    /// 6. `[]` Token program.
    /// 7. `[]` Clock sysvar.
    Unstake,
    /// Claim accrued rewards without withdrawing principal.
    ///
    /// Accounts: same as `Unstake`.
    Claim,
    /// Admin: queue a parameter update. It only takes effect after the timelock
    /// delay via `ApplyParams` (which anyone may call once the delay elapses).
    /// `None` fields keep their current values. Accounts:
    /// 0. `[signer]` Admin. 1. `[writable]` Config PDA. 2. `[]` Clock sysvar.
    UpdateParams {
        fee_bps: Option<u16>,
        reward_rate_bps: Option<u64>,
        min_stake: Option<u64>,
        unstake_delay: Option<i64>,
        timelock_secs: Option<i64>,
    },
    /// Apply the queued parameter update once the timelock has elapsed.
    /// Permissionless. Accounts:
    /// 0. `[writable]` Config PDA. 1. `[]` Clock sysvar.
    ApplyParams,
    /// Admin: cancel the queued parameter update. Accounts:
    /// 0. `[signer]` Admin. 1. `[writable]` Config PDA.
    CancelParams,
    /// Admin: halt new deposits (withdrawals stay enabled). Accounts:
    /// 0. `[signer]` Admin. 1. `[writable]` Config PDA.
    Pause,
    /// Admin: resume deposits. Accounts: same as `Pause`.
    Unpause,
    /// Admin: propose a new admin (step 1 of a two-step transfer). Accounts:
    /// 0. `[signer]` Admin. 1. `[writable]` Config PDA.
    TransferAdmin { new_admin: Pubkey },
    /// Proposed admin: accept the transfer, becoming the admin (step 2).
    /// Accounts: 0. `[signer]` Pending admin. 1. `[writable]` Config PDA.
    AcceptAdmin,
    /// Admin: ONE-TIME genesis mint of the initial supply to a recipient token
    /// account. Succeeds at most once per deployment (latched by
    /// `Config::genesis_done`); every later attempt fails with
    /// `GenesisAlreadyDone`. This is the only sanctioned initial-distribution
    /// path — after it, minting is limited to reward accrual on stake.
    ///
    /// Accounts:
    /// 0. `[signer]` Admin.
    /// 1. `[writable]` Config PDA.
    /// 2. `[writable]` Mint (must equal `Config::mint`).
    /// 3. `[writable]` Recipient token account (of the mint).
    /// 4. `[]` Token program.
    GenesisMint { amount: u64 },
}

impl StakingInstruction {
    /// Borsh-encode to instruction data.
    pub fn pack(&self) -> Result<Vec<u8>, StakingError> {
        borsh::to_vec(self).map_err(|_| StakingError::InvalidInstructionData)
    }

    /// Decode instruction data.
    pub fn unpack(data: &[u8]) -> Result<Self, StakingError> {
        Self::try_from_slice(data).map_err(|_| StakingError::InvalidInstructionData)
    }
}

// ---------------------------------------------------------------------------
// Client-side instruction builders (used by the CLI and tests).
// ---------------------------------------------------------------------------

/// Build a `Stake` instruction.
pub fn stake_ix(
    program_id: &Pubkey,
    staker: &Pubkey,
    staker_token: &Pubkey,
    vault: &Pubkey,
    treasury: &Pubkey,
    amount: u64,
) -> Result<Instruction, StakingError> {
    let (config_pda_key, _) = config_pda(program_id);
    let (stake_key, _) = stake_pda(program_id, staker);
    let data = StakingInstruction::Stake { amount }.pack()?;
    Ok(Instruction {
        program_id: *program_id,
        accounts: vec![
            AccountMeta::new(*staker, true),
            AccountMeta::new(*staker_token, false),
            AccountMeta::new(*vault, false),
            AccountMeta::new(*treasury, false),
            AccountMeta::new(stake_key, false),
            AccountMeta::new_readonly(config_pda_key, false),
            AccountMeta::new_readonly(spl_token::id(), false),
            AccountMeta::new_readonly(system_program::id(), false),
            AccountMeta::new_readonly(sysvar::clock::id(), false),
        ],
        data,
    })
}

/// Build an `Unstake` instruction.
pub fn unstake_ix(
    program_id: &Pubkey,
    staker: &Pubkey,
    staker_token: &Pubkey,
    vault: &Pubkey,
    mint: &Pubkey,
) -> Result<Instruction, StakingError> {
    let (config_pda_key, _) = config_pda(program_id);
    let (stake_key, _) = stake_pda(program_id, staker);
    let data = StakingInstruction::Unstake.pack()?;
    Ok(Instruction {
        program_id: *program_id,
        accounts: vec![
            AccountMeta::new(*staker, true),
            AccountMeta::new(*staker_token, false),
            AccountMeta::new(*vault, false),
            AccountMeta::new(*mint, false),
            AccountMeta::new(stake_key, false),
            AccountMeta::new_readonly(config_pda_key, false),
            AccountMeta::new_readonly(spl_token::id(), false),
            AccountMeta::new_readonly(sysvar::clock::id(), false),
        ],
        data,
    })
}

/// Build a `Claim` instruction (same accounts as unstake).
pub fn claim_ix(
    program_id: &Pubkey,
    staker: &Pubkey,
    staker_token: &Pubkey,
    vault: &Pubkey,
    mint: &Pubkey,
) -> Result<Instruction, StakingError> {
    let mut ix = unstake_ix(program_id, staker, staker_token, vault, mint)?;
    ix.data = StakingInstruction::Claim.pack()?;
    Ok(ix)
}

/// Build an admin-only instruction (`Pause` / `Unpause` / `TransferAdmin` /
/// `AcceptAdmin` / `CancelParams`). They all take the same two accounts:
/// 0. `[signer]` the authority (current admin, or pending admin for accept).
/// 1. `[writable]` the config PDA.
pub fn admin_ix(
    program_id: &Pubkey,
    authority: &Pubkey,
    ix: StakingInstruction,
) -> Result<Instruction, StakingError> {
    let (config_pda_key, _) = config_pda(program_id);
    let data = ix.pack()?;
    Ok(Instruction {
        program_id: *program_id,
        accounts: vec![
            AccountMeta::new(*authority, true),
            AccountMeta::new(config_pda_key, false),
        ],
        data,
    })
}

/// Build an `UpdateParams` (queue) instruction. Accounts:
/// 0. `[signer]` admin. 1. `[writable]` config PDA. 2. `[]` clock sysvar.
#[allow(clippy::too_many_arguments)]
pub fn update_params_ix(
    program_id: &Pubkey,
    admin: &Pubkey,
    fee_bps: Option<u16>,
    reward_rate_bps: Option<u64>,
    min_stake: Option<u64>,
    unstake_delay: Option<i64>,
    timelock_secs: Option<i64>,
) -> Result<Instruction, StakingError> {
    let (config_pda_key, _) = config_pda(program_id);
    let data = StakingInstruction::UpdateParams {
        fee_bps,
        reward_rate_bps,
        min_stake,
        unstake_delay,
        timelock_secs,
    }
    .pack()?;
    Ok(Instruction {
        program_id: *program_id,
        accounts: vec![
            AccountMeta::new(*admin, true),
            AccountMeta::new(config_pda_key, false),
            AccountMeta::new_readonly(sysvar::clock::id(), false),
        ],
        data,
    })
}

/// Build an `ApplyParams` instruction (permissionless once the timelock has
/// elapsed). Accounts: 0. `[writable]` config PDA. 1. `[]` clock sysvar.
pub fn apply_params_ix(program_id: &Pubkey) -> Result<Instruction, StakingError> {
    let (config_pda_key, _) = config_pda(program_id);
    let data = StakingInstruction::ApplyParams.pack()?;
    Ok(Instruction {
        program_id: *program_id,
        accounts: vec![
            AccountMeta::new(config_pda_key, false),
            AccountMeta::new_readonly(sysvar::clock::id(), false),
        ],
        data,
    })
}

/// Build a `GenesisMint` instruction (one-time initial distribution).
pub fn genesis_mint_ix(
    program_id: &Pubkey,
    admin: &Pubkey,
    mint: &Pubkey,
    recipient: &Pubkey,
    amount: u64,
) -> Result<Instruction, StakingError> {
    let (config_key, _) = config_pda(program_id);
    Ok(Instruction {
        program_id: *program_id,
        accounts: vec![
            AccountMeta::new(*admin, true),
            AccountMeta::new(config_key, false),
            AccountMeta::new(*mint, false),
            AccountMeta::new(*recipient, false),
            AccountMeta::new_readonly(spl_token::id(), false),
        ],
        data: StakingInstruction::GenesisMint { amount }.pack()?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn instruction_roundtrips() {
        let ix = StakingInstruction::Initialize {
            fee_bps: 100,
            reward_rate_bps: 1000,
            min_stake: 1_000_000,
            unstake_delay: 3600,
            decimals: 6,
            timelock_secs: 86_400,
        };
        let bytes = ix.pack().unwrap();
        assert_eq!(StakingInstruction::unpack(&bytes).unwrap(), ix);
    }

    #[test]
    fn stake_instruction_roundtrips() {
        let ix = StakingInstruction::Stake { amount: 42 };
        let bytes = ix.pack().unwrap();
        assert_eq!(StakingInstruction::unpack(&bytes).unwrap(), ix);
        // Discriminant differs between variants.
        let other = StakingInstruction::Unstake.pack().unwrap();
        assert_ne!(bytes[0], other[0]);
    }

    #[test]
    fn genesis_mint_roundtrips_with_distinct_discriminant() {
        let ix = StakingInstruction::GenesisMint { amount: 123_456 };
        let bytes = ix.pack().unwrap();
        assert_eq!(StakingInstruction::unpack(&bytes).unwrap(), ix);
        assert_ne!(bytes[0], StakingInstruction::AcceptAdmin.pack().unwrap()[0]);
    }

    #[test]
    fn update_params_with_options_roundtrips() {
        let ix = StakingInstruction::UpdateParams {
            fee_bps: Some(50),
            reward_rate_bps: None,
            min_stake: Some(5),
            unstake_delay: None,
            timelock_secs: Some(7_200),
        };
        let bytes = ix.pack().unwrap();
        assert_eq!(StakingInstruction::unpack(&bytes).unwrap(), ix);
    }

    #[test]
    fn governance_variants_roundtrip_with_distinct_discriminants() {
        let variants = [
            StakingInstruction::Pause,
            StakingInstruction::Unpause,
            StakingInstruction::TransferAdmin {
                new_admin: Pubkey::new_unique(),
            },
            StakingInstruction::AcceptAdmin,
            StakingInstruction::ApplyParams,
            StakingInstruction::CancelParams,
        ];
        let mut discriminants = std::collections::HashSet::new();
        for v in &variants {
            let bytes = v.pack().unwrap();
            assert_eq!(&StakingInstruction::unpack(&bytes).unwrap(), v);
            discriminants.insert(bytes[0]);
        }
        assert_eq!(
            discriminants.len(),
            variants.len(),
            "every variant must have a distinct discriminant"
        );
    }

    #[test]
    fn governance_builders_pin_the_config_pda() {
        let pid = Pubkey::new_unique();
        let admin = Pubkey::new_unique();
        let (config_key, _) = config_pda(&pid);

        let up = update_params_ix(&pid, &admin, Some(10), None, None, None, None).unwrap();
        assert_eq!(up.accounts[0].pubkey, admin);
        assert!(up.accounts[0].is_signer);
        assert_eq!(up.accounts[1].pubkey, config_key);
        assert!(up.accounts[1].is_writable);
        assert_eq!(up.accounts[2].pubkey, sysvar::clock::id());

        let ap = apply_params_ix(&pid).unwrap();
        assert_eq!(ap.accounts[0].pubkey, config_key);
        assert!(ap.accounts[0].is_writable);
        assert!(
            !ap.accounts.iter().any(|a| a.is_signer),
            "apply is permissionless"
        );

        let cx = admin_ix(&pid, &admin, StakingInstruction::CancelParams).unwrap();
        assert_eq!(cx.accounts.len(), 2);
        assert!(cx.accounts[0].is_signer);
    }

    #[test]
    fn bad_data_is_rejected() {
        assert!(StakingInstruction::unpack(&[9, 9, 9, 9, 9]).is_err());
    }

    #[test]
    fn client_builder_sets_the_program_and_signer() {
        let pid = Pubkey::new_unique();
        let staker = Pubkey::new_unique();
        let ix = stake_ix(
            &pid,
            &staker,
            &Pubkey::new_unique(),
            &Pubkey::new_unique(),
            &Pubkey::new_unique(),
            1000,
        )
        .unwrap();
        assert_eq!(ix.program_id, pid);
        assert!(ix.accounts[0].is_signer);
        assert!(ix.accounts[0].is_writable);
        // Config PDA is present and read-only.
        assert!(ix
            .accounts
            .iter()
            .any(|a| a.pubkey == config_pda(&pid).0 && !a.is_writable));
    }
}
