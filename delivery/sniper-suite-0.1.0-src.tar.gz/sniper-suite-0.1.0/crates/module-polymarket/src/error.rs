//! Errors for the Polymarket module.
//!
//! Kept separate from `bot_core::error::BotError` because the Polymarket client
//! has failure modes (EIP-712 encoding, CLOB auth, tick-size rounding) that do
//! not map cleanly onto the Solana-centric core errors. A `From<PolyError> for
//! BotError` lets module code bubble up into the shared error channel.

use thiserror::Error;

/// Polymarket module result.
pub type PolyResult<T> = Result<T, PolyError>;

/// Polymarket module error.
#[derive(Debug, Error)]
pub enum PolyError {
    /// A configuration or input value was malformed.
    #[error("invalid input: {0}")]
    Invalid(String),
    /// An HTTP/transport failure talking to Gamma, CLOB or the data API.
    #[error("http error: {0}")]
    Http(String),
    /// The CLOB returned a non-success or an error payload.
    #[error("clob error: {0}")]
    Clob(String),
    /// The POST ended in a transport failure: the signed order MAY or may
    /// not be resting on the book. Carries the locally derived CLOB order id
    /// so reconciliation can query the venue for the truth.
    #[error("submit unknown (derived order {order_id}): {reason}")]
    SubmitUnknown {
        /// Locally derived CLOB order id (`0x`-hex EIP-712 struct hash).
        order_id: String,
        /// Underlying transport failure description.
        reason: String,
    },
    /// A JSON (de)serialization failure.
    #[error("encoding error: {0}")]
    Encoding(String),
    /// Signing / key material problem.
    #[error("signing error: {0}")]
    Signing(String),
    /// The module is not configured (no key, disabled, etc.).
    #[error("not configured: {0}")]
    NotConfigured(String),
    /// A websocket failure.
    #[error("websocket error: {0}")]
    Ws(String),
}

impl PolyError {
    /// Malformed input.
    pub fn invalid(msg: impl Into<String>) -> Self {
        PolyError::Invalid(msg.into())
    }
    /// Transport failure.
    pub fn http(msg: impl Into<String>) -> Self {
        PolyError::Http(msg.into())
    }
    /// CLOB-level failure.
    pub fn clob(msg: impl Into<String>) -> Self {
        PolyError::Clob(msg.into())
    }
    /// JSON failure.
    pub fn encoding(msg: impl Into<String>) -> Self {
        PolyError::Encoding(msg.into())
    }
    /// Signing failure.
    pub fn signing(msg: impl Into<String>) -> Self {
        PolyError::Signing(msg.into())
    }
    /// Missing configuration.
    pub fn not_configured(msg: impl Into<String>) -> Self {
        PolyError::NotConfigured(msg.into())
    }
    /// Websocket failure.
    pub fn ws(msg: impl Into<String>) -> Self {
        PolyError::Ws(msg.into())
    }
}

impl From<reqwest::Error> for PolyError {
    fn from(e: reqwest::Error) -> Self {
        PolyError::Http(e.to_string())
    }
}

impl From<serde_json::Error> for PolyError {
    fn from(e: serde_json::Error) -> Self {
        PolyError::Encoding(e.to_string())
    }
}

impl From<hex::FromHexError> for PolyError {
    fn from(e: hex::FromHexError) -> Self {
        PolyError::Encoding(format!("hex: {e}"))
    }
}

impl From<bot_core::error::BotError> for PolyError {
    fn from(e: bot_core::error::BotError) -> Self {
        PolyError::Clob(e.to_string())
    }
}

impl From<PolyError> for bot_core::error::BotError {
    fn from(e: PolyError) -> Self {
        match e {
            PolyError::Invalid(m) => bot_core::error::BotError::invalid(m),
            PolyError::Http(m) => bot_core::error::BotError::http(m),
            PolyError::Encoding(m) => bot_core::error::BotError::encoding(m),
            PolyError::Signing(m) => bot_core::error::BotError::other(m),
            PolyError::NotConfigured(m) => bot_core::error::BotError::config(m),
            PolyError::Ws(m) => bot_core::error::BotError::ws(m),
            PolyError::Clob(m) => bot_core::error::BotError::other(m),
            PolyError::SubmitUnknown { order_id, reason } => bot_core::error::BotError::other(
                format!("polymarket submit unknown (order {order_id}): {reason}"),
            ),
        }
    }
}
