# Evidence index — claim → source map

Every major claim made anywhere in the buyer package, mapped to the file and
section that evidences it, with its verification status and date. Purpose: a
buyer's due-diligence team can check any claim in one hop. Status labels per
`docs/HANDOVER.md` §3. Dates: engineering evidence was produced 2026-09-17
(build sessions) and 2026-09-18 (release + freeze passes), as recorded in
`AUDIT.md`'s dated sections.

## Test & gate claims

| Claim | Evidence file | Evidence section | Status / date |
|---|---|---|---|
| 521/521 workspace tests, 0 failures (incl. 38 gated executed) | `AUDIT.md`; `docs/TESTING.md`; `release-manifest.json` | §27 (freeze gate run); §"What is covered where"; `test_counts.workspace_total` | VERIFIED — 2026-09-18 |
| db_integration 23/23 vs real PostgreSQL 16.4 (fresh + rerun) | `AUDIT.md`; `docs/TESTING.md` | §27; db_integration bullet (line ~49) | VERIFIED — 2026-09-18 |
| redis_integration 10/10 vs real Redis 7.2.10 | `AUDIT.md`; `docs/TESTING.md` | §27; redis bullet (line ~75) | VERIFIED — 2026-09-18 |
| distributed_integration 4/4 | `AUDIT.md`; `docs/TESTING.md` | §27; distributed bullet (line ~82) | VERIFIED — 2026-09-18 |
| two_replica_mirror 1/1 (two real processes) | `AUDIT.md`; `docs/TESTING.md`; `crates/module-copy/tests/two_replica_mirror.rs` | §27; test source | VERIFIED — 2026-09-18 |
| Staking host 48/48 | `AUDIT.md`; `docs/STAKING.md`; `release-manifest.json` | §27; `test_counts.staking_host` | VERIFIED — 2026-09-18 |
| Staking validator e2e 2/2 (funded stake→reward→unstake, local validator) | `AUDIT.md`; `docs/STAKING.md`; `programs/staking-suite/tests/validator_e2e.rs` | earlier dated sections; e2e source | PREVIOUSLY VERIFIED — 2026-09-17 era (agave 2.1.21) |
| `cargo build-sbf` → 5,440-byte `staking_suite.so` | `AUDIT.md`; `release-manifest.json` | earlier sections; `previously_verified_identical_source` | PREVIOUSLY VERIFIED |
| release-check 20 PASS / 0 FAIL / 0 SKIP, exit 0 | `AUDIT.md`; `release-manifest.json`; `scripts/release-check.sh` | §27 (definitive run on frozen tree); `test_counts.release_check_gates` | VERIFIED — 2026-09-18 |
| 609 whole-script test executions / 0 failures | `AUDIT.md` | §27 | VERIFIED — 2026-09-18 |
| fmt + clippy `-D warnings` clean (both cargo projects) | `AUDIT.md`; `release-manifest.json` | §26–27; `verified_final_pass` | VERIFIED — 2026-09-18 |
| cargo-audit ×2 = 0 findings (cargo-audit 0.22.2) | `AUDIT.md`; `release-manifest.json`; `docs/THIRD-PARTY.md` | §27; `verified_final_pass`; §5 | VERIFIED — 2026-09-18 |
| cargo-deny ok (advisories/bans/licenses/sources; 0.18.9) | `AUDIT.md`; `deny.toml`; `docs/THIRD-PARTY.md` | §27; policy file; §4 | VERIFIED — 2026-09-18 |
| recon_crash_e2e vs local solana-test-validator | `AUDIT.md`; `crates/solana-kit/tests/recon_crash_e2e.rs` | earlier dated sections | PREVIOUSLY VERIFIED |
| devnet_e2e read-only vs public devnet; latency_bench | `AUDIT.md`; `crates/solana-kit/tests/{devnet_e2e,latency_bench}.rs` | earlier dated sections | PREVIOUSLY VERIFIED |
| Deterministic ledger replay | `AUDIT.md` | earlier dated sections | PREVIOUSLY VERIFIED |

## Security & correctness claims

| Claim | Evidence file | Evidence section | Status / date |
|---|---|---|---|
| pg_dump → restore → full db_integration suite green on restored DB | `AUDIT.md`; `docs/BACKUP-RESTORE.md`; `docs/HANDOVER.md` | §26–27; procedures; §2 | VERIFIED — 2026-09-18 |
| Audit-chain tamper detection (modify/reorder/missing/duplicate) + linear chain under 8 concurrent appenders | `AUDIT.md`; `crates/core/tests/db_integration.rs`; `crates/core/src/db/repo.rs` | §26 (fix + tests); chain tests; advisory-lock append | VERIFIED — 2026-09-18 |
| Telegram bot-token redaction in all API error paths (+ closed-port regression test) | `AUDIT.md`; `crates/module-telegram/src/api.rs`; `CHANGELOG.md` | §27; `without_url()` sites + `error_strings_never_contain_the_bot_token`; "Fixed (engineering-freeze pass)" | VERIFIED — 2026-09-18 |
| No secrets / no build artifacts in tree; marker scan clean | `scripts/release-check.sh`; `AUDIT.md` | secret_scan + marker_scan gates; §27 | VERIFIED — 2026-09-18 |
| Migrations monotonic 0001–0011; version + toolchain-pin consistency | `scripts/release-check.sh`; `crates/core/migrations/` | migration_check + version_check + toolchain_check gates | VERIFIED — 2026-09-18 |
| RBAC: readonly-cannot-mutate, operator≠owner, live-mode owner-only | `crates/core/src/auth.rs`; `crates/module-telegram/src/commands.rs`; test suite | authz tests within the 521 | VERIFIED — 2026-09-18 |
| No external security audit exists (any component) | root `SECURITY.md`; `docs/SECURITY.md`; `release-manifest.json` | "What this document is not"; `not_executed_environment_blocked` | FACT — current |

## Packaging & metadata claims

| Claim | Evidence file | Evidence section | Status / date |
|---|---|---|---|
| Version 0.1.0 consistent across VERSION / Cargo.toml / manifest | `VERSION`; `Cargo.toml`; `release-manifest.json`; `scripts/release-check.sh` | version_check gate | VERIFIED — 2026-09-18 |
| Frozen tree: 146 files / 2,801,590 B / 77,980 lines; category breakdown | `docs/FINAL-DELIVERY.md`; `docs/BUYER-DUE-DILIGENCE.md` | §3; §A (measurement commands included for re-verification) | VERIFIED measurement — 2026-09-18 |
| Documentation passes changed no code bytes (byte-exact category proofs) | pass reports (`COMMERCIAL_PACKAGE_REPORT.md` §7 in the seller's workspace; re-derivable with the commands in `docs/BUYER-DUE-DILIGENCE.md` §A) | byte arithmetic: Rust 2,051,936 B, SQL 23,443 B unchanged | VERIFIED — 2026-09-18 (buyer package pass) |
| Documentation consistency clean (links, counts, versions, paths, invisible chars) | `scripts/verify-delivery.sh` (in-repo checker) | whole script | VERIFIED — re-runnable at any time |
| Docker image build + smoke not executed in delivery environment | `release-manifest.json`; `.github/workflows/ci.yml` | `not_executed_environment_blocked`; docker job | NOT EXECUTED — fact |
| CI workflow delivered, never run from delivery environment | `.github/workflows/ci.yml`; `release-manifest.json` | 4 jobs; `not_executed_environment_blocked` | NOT EXECUTED — fact |
| Funded live trading never executed | `release-manifest.json`; `docs/TESTING.md` | `not_executed_environment_blocked`; §Known gaps | NOT EXECUTED — fact |
| SBOM generator not run; lockfiles authoritative (706 + 580 packages) | `docs/THIRD-PARTY.md`; `Cargo.lock`; `programs/staking-suite/Cargo.lock` | §1, §6 | NOT EXECUTED (SBOM) / FACT (lockfiles) |
| Authoritative history `9c677cd` → `0e139c3` | `AUDIT.md`; `CHANGELOG.md`; `release-manifest.json` notes; `docs/FINAL-DELIVERY.md` | §26–27 headers; release identity; manifest design note; §2 | FACT — recorded in the authoritative repository (git metadata absent from the packaging sandbox; never fabricated) |

## How to re-verify anything above

1. **Whole gate:** `./scripts/release-check.sh` (needs PG + Redis) — reproduces
   every VERIFIED test/gate claim in one run.
2. **Bundle/docs:** `./scripts/verify-delivery.sh` (no toolchain needed).
3. **Individual suites:** exact commands in README §Testing and
   `docs/TESTING.md`.
4. **Sizes/counts:** commands in `docs/BUYER-DUE-DILIGENCE.md` §A.
5. **Historical narrative:** `AUDIT.md` (dated sections, oldest → newest;
   historical sections are preserved unmodified by policy).
