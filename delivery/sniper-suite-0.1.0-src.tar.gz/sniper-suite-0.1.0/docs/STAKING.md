# Staking program (Module 4)

Native Solana program (no Anchor), declared id
`3vEEMMFmdA88n8ApgZ3b9L3BXEh75yCeMbHbmUjR9mfy` (`staking_suite::ID`).
Single SPL-token staking pool with deposit fees, time-based reward minting,
a public parameter timelock, two-step admin transfer, and a one-time latched
genesis mint.

## Economics

* **Deposit fee** `fee_bps` (cap: 1000 = 10%) — taken on every `Stake`,
  routed to the treasury token account. Principal net of fee goes to the
  vault (a token account owned by the config PDA).
* **Rewards** `reward_rate_bps` annual (cap: 10000 = 100%/yr), linear:
  `amount * rate_bps * elapsed_secs / (10_000 * 31_536_000)`, rounded down,
  settled on `Claim`/`Unstake` and **minted** (supply grows by exactly the
  payout). Top-ups settle accrued rewards first so nothing is lost.
* **Cooldown** `unstake_delay` seconds before principal can be withdrawn.
* **Pause** blocks deposits only — `Unstake`/`Claim` can never be paused, so
  the admin can halt new money during an incident but can never freeze user
  funds.

## Governance

* `UpdateParams` (admin) queues a change; it becomes applicable only after
  `timelock_secs` (cap: 30 days) via `ApplyParams`, which is
  **permissionless** — anyone can push a published, expired update through,
  and caps are re-checked at apply time. `CancelParams` (admin) withdraws a
  queued update. Changing `timelock_secs` itself goes through the current
  timelock.
* `TransferAdmin` (admin proposes) + `AcceptAdmin` (proposed key signs) —
  two-step, so control can never be handed to an unowned key.
* `GenesisMint` (admin, **once per deployment**): mints the initial supply to
  a recipient token account and flips `Config::genesis_done`; every later
  attempt fails with `GenesisAlreadyDone` (error 6026). This is the only
  sanctioned initial distribution — afterwards the mint authority (the
  config PDA) only ever mints accrued rewards.

## Accounts

| Account | Derivation | Contents |
|---|---|---|
| Config PDA | seeds `["staking-config"]` | `Config` (borsh): admin, mint, vault, treasury, params, pause, pending admin/update, genesis latch |
| Mint | keypair signer at `Initialize`; mint authority = config PDA; **no freeze authority** | SPL mint |
| Vault | ATA of config PDA on the mint | all staked principal |
| Treasury | ATA of the treasury wallet | collected fees |
| Stake PDA | seeds `["staking-stake", staker]` | `StakeAccount`: owner, amount, staked_at, reward_from, pending_rewards |

## Instructions (borsh enum, discriminant = first byte)

`Initialize` · `Stake{amount}` · `Unstake` · `Claim` · `UpdateParams{...}` ·
`ApplyParams` · `CancelParams` · `Pause` · `Unpause` ·
`TransferAdmin{new_admin}` · `AcceptAdmin` · `GenesisMint{amount}`

Client builders for all of them live in `staking_suite::instruction`
(`stake_ix`, `unstake_ix`, `claim_ix`, `admin_ix`, `update_params_ix`,
`apply_params_ix`, `genesis_mint_ix`). Errors are `Custom(6000 + n)` —
see `error.rs` for the full table (e.g. 6018 Paused, 6024
TimelockNotElapsed, 6026 GenesisAlreadyDone, 6027 InvalidAmount).

## Deploy + launch sequence

```bash
cd programs/staking-suite
cargo build-sbf                       # agave 2.1.21 toolchain (see CI notes)
solana program deploy target/deploy/staking_suite.so \
  --program-id target/deploy/staking_suite-keypair.json   # or your fixed id
```

Then, as admin (payer of initialize becomes admin):

1. `Initialize { fee_bps, reward_rate_bps, min_stake, unstake_delay,
   decimals, timelock_secs }` — creates mint (new keypair signs), vault,
   treasury, config PDA in one tx. Production should use `timelock_secs`
   ≥ 24h.
2. Create the distribution wallet's ATA for the mint.
3. `GenesisMint { amount }` to that ATA — **once**; verify
   `Config::genesis_done == true` and `Mint::supply == amount` afterwards.
4. Distribute tokens off-chain / via your sale process; verify on-chain
   balances match your records (the program cannot know about your sale).
5. Publish the mint address + program id for stakers.

## Testing status (honest)

* **Host unit tests (48):** instruction round-trips, borsh layouts, reward /
  fee math (incl. overflow saturation), signer/address/owner guards,
  timelock validation, genesis authorization/latch/amount/mint checks.
  `cargo test` in `programs/staking-suite`.
* **Validator e2e (2 tests, VERIFIED locally** against a real
  `solana-test-validator` running the compiled BPF, 84s):
  governance lifecycle (initialize, re-init guard, stake guards, pause
  authorization, timelock queue/apply/cancel with caps, two-step admin
  transfer) and the funded money flow (genesis mint → stake with fee split →
  reward accrual → claim mints exactly the payout → unstake drains the
  vault; genesis replay → 6026; non-admin genesis → Unauthorized).
  Run: `STAKING_E2E=1 cargo test --test validator_e2e -- --test-threads=1`.
* **NOT done:** third-party audit, mainnet deployment, fuzzing. Reward math
  is linear/simple by design; caps are enforced at both queue and apply
  time. Do not claim this program is "audited" — it is well-tested, not
  audited.
