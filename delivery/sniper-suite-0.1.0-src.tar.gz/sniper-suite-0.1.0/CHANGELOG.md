# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

The canonical version lives in `[workspace.package].version` in the root
`Cargo.toml`; the `VERSION` file mirrors it and `scripts/release-check.sh`
fails the release if they ever disagree.

## [Unreleased]

### Added (buyer / due-diligence documentation pass — no source code changed)

- 14 buyer-package documents under `docs/`: BUYER-OVERVIEW,
  CAPABILITY-MATRIX, BUYER-DUE-DILIGENCE, IP-COMPONENTS, THIRD-PARTY,
  BUYER-DEPLOYMENT, ACCEPTANCE-CHECKLIST, RELEASE-NOTES-0.1.0, BUYER-FAQ,
  SCOPE-BOUNDARY, SUPPORT-HANDOVER, BUYER-RISK-REGISTER,
  TECHNICAL-DIFFERENTIATORS, DELIVERY-MANIFEST (index).
- README "Buyer / engineering handover" section; `docs/HANDOVER.md` §1 and
  `release-manifest.json` `docs_count` updated for the new document set
  (13 → 27 files under `docs/`). The frozen engineering tree (commit
  `0e139c3`) is untouched: no Rust, SQL, config or CI file changed.

### Added (final delivery package — documentation + bundle tooling only)

- 9 final-delivery documents under `docs/`: FINAL-DELIVERY (single starting
  point), BUYER-QUICKSTART (18-step walkthrough), TECHNICAL-FACT-SHEET,
  SELLER-FACT-SHEET, SELLING-LISTING-SOURCE (factual listing source
  material — not advertising), DEMO-RUNBOOK (10 deterministic demos),
  EVIDENCE-INDEX (claim → evidence map), REPOSITORY-MAP (annotated tree),
  ARCHIVE-CHECKLIST (seller archive INCLUDE/EXCLUDE spec).
- `scripts/verify-delivery.sh` — fast, fail-closed bundle-integrity check
  (required files, version identity, docs count, hygiene, markdown links,
  invisible characters). Complements `release-check.sh`; builds/tests
  nothing.
- CAPABILITY-MATRIX and BUYER-RISK-REGISTER finalized to the delivery column
  schema; IP-COMPONENTS gained the ownership-transfer checklist;
  DELIVERY-MANIFEST indexes all 23 buyer/delivery docs; README/HANDOVER
  pointers and `release-manifest.json` `docs_count` (27 → 36) updated.
  Still zero changes to Rust, SQL, migrations, configs, Docker or CI files.

## [0.1.0] — initial handover release

First complete, internally verified release of the suite. Delivered state
(full evidence trail in `AUDIT.md`, test inventory in `docs/TESTING.md`):

### Added

- **Module 1 — Sniper** (`module-sniper`): pump.fun launch detection
  (PumpPortal WS, Yellowstone-style Geyser `transactionSubscribe`, poll
  fallback) and entry execution with PumpSwap/Raydium/Jupiter exit routing.
- **Module 2 — Copy trading** (`module-copy`): tracked-wallet mirroring with
  per-wallet rules, sizing, staleness guards and mirrored exits.
- **Module 3 — Polymarket** (`module-polymarket`): Gamma + CLOB REST/WS
  integration with EIP-712 v2 order signing and CTF ERC-1155 balance reads.
- **Module 4 — Staking program** (`programs/staking-suite`): native Solana
  program — reward mint, vault + fee treasury, per-second APY accrual,
  parameter timelock (queue/apply/cancel), two-step admin transfer,
  pause-deposits-only, hard parameter caps, one-time latched `GenesisMint`.
- **Module 5 — Telegram control** (`module-telegram`): deny-by-default RBAC,
  kill switch, module on/off, rate-limited alerts.
- **Control plane** (`server`): Axum REST (23 REST endpoints over 21
  `/api` routes) + WebSocket event feed (`/api/events`) + 4 infra routes —
  28 endpoints documented route-by-route in `docs/API.md` +
  embedded dashboard; liveness/readiness probes; Prometheus metrics with
  bounded labels; request-ID correlation; per-IP and per-principal rate
  limits; refusal to bind non-loopback without API auth.
- **Core** (`bot-core`): typed config with validation and env overrides,
  global risk engine (capacity, exposure, daily-loss auto-disable), OMS state
  machine with idempotency keys, restart-safe dedup (memory/Redis/Postgres),
  hash-chained append-only audit trail, JSONL journal with rotation and
  corrupt-line tolerance, intent journal + startup reconciliation,
  Postgres repositories with 11 forward-only migrations.
- **Distributed execution ownership** (`docs/DISTRIBUTED.md`): one logical
  execution ⇒ at most one active owner ⇒ at most one money-moving submission.
  Claim stores (Postgres authoritative, Redis, memory), leases + epochs +
  fencing, handoff grace for ambiguous outcomes, cross-replica kill-switch /
  module-flag sync, position-book sync, cluster-wide `GlobalRiskOracle`
  (tighten-only), and the append-only `execution_claim_events` lineage table.
- **Solana kit** (`solana-kit`): RPC retry/failover/fan-out, WS supervision
  with resubscribe, account cache (TTL + FIFO bounds), pump/raydium/pumpswap
  instruction builders, transaction executor with simulate-first policy and
  signer registry (multi-signer safe).
- **Operations**: Dockerfile (multi-stage, non-root, healthchecked),
  docker-compose stack (Postgres 16 + Redis 7, healthcheck-gated),
  `.env.template`, single-workflow CI (fmt/clippy `-D warnings`/build/test
  with real service containers, staking `build-sbf` + validator e2e,
  cargo-audit + cargo-deny hard gates, docker image build + smoke test),
  `scripts/release-check.sh` local release gate, machine-readable
  `release-manifest.json`, and thirteen docs under `docs/`.

### Fixed (during the release-engineering pass, pre-tag)

- **Audit chain append serialization** — `AuditRepo::append` previously read
  the chain head with `SELECT … ORDER BY id DESC LIMIT 1 FOR UPDATE`, which
  does not serialize concurrent writers under READ COMMITTED (a blocked
  writer's snapshot never sees the winner's new head row → the chain forks
  and `/api/audit/verify` reports a false break). Appends are now serialized
  by a transaction-scoped advisory lock
  (`pg_advisory_xact_lock(hashtext('audit_events_chain'))`). Regression
  tests: concurrent-append linearization + reordered/missing/duplicate row
  detection (`db_integration`).
- Toolchain-pin drift: the Dockerfile built on `rust:1.82` and the CI
  `program` job on unpinned `stable`, contradicting the `rust-toolchain.toml`
  pin (1.98.1). Both now use 1.98.1; `scripts/release-check.sh` gates the
  three-way consistency.
- Removed the placeholder `repository` URL (`example.com/...`) from the
  workspace manifest; stale test counts and an undocumented route-subset
  table in README corrected.

### Fixed (engineering-freeze pass, pre-tag)

- **Telegram bot-token leak into error strings** — the Bot API embeds the
  token in every request URL and `reqwest::Error`'s `Display` appends
  ` for url (…)` on send errors, so failed Telegram calls put the token into
  tracing logs / audit detail / alert text. Every reqwest error mapping in
  `module-telegram` now strips the URL (`Error::without_url()`); regression
  test `error_strings_never_contain_the_bot_token` exercises all four API
  methods against a closed loopback port and fails if the token ever appears
  in an error string.
- **Unused dependencies removed** (verified zero code references before
  removal, `cargo check` + full gate re-run after): `tokio-util` (core,
  solana-kit, server), `sha3` (module-polymarket — EIP-712 uses
  `tiny-keccak`), `serde_with` (workspace entry no crate referenced). They
  remain in `Cargo.lock` only where still required transitively.
- **Release metadata drift corrected:** control-plane route count and docs
  count in this file now match the source (26 `.route()` registrations /
  28 documented endpoints; 13 docs); `release-manifest.json` added as the
  machine-readable delivery manifest and wired into `release-check.sh`
  (required file + version consistency).

### Verification status at cut

- 521 application workspace tests (incl. 38 gated Postgres/Redis/
  distributed/two-replica integration tests), 48+2 staking host/e2e-gated
  tests — 0 failures; `scripts/release-check.sh` 20/20 gates PASS; fmt, clippy `-D warnings`, cargo-audit, cargo-deny
  clean. Per-pass evidence and the honest NOT-EXECUTED /
  ENVIRONMENT-BLOCKED list: `docs/HANDOVER.md` and `docs/TESTING.md`.
- The staking program has **not** had an external security audit; the
  declared program id is a pre-deploy placeholder. Do not deploy to mainnet
  until an independent audit passes (see `docs/SECURITY.md`).

[0.1.0]: initial release — no previous tags exist.
